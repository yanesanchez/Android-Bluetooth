package com.example.a12_bt_onepage;

public interface FragmentDataPassListener {
    public void cf_firedByFragment(String str, int source);
}
